export const white = '#FFF'
export const black = '#333'

export const green = {
  500: '#333',
}

export const red = {
  100: '#333',
  200: '#333',
  500: '#333',
}

export const grey = {
  100: '#f7f4f2',
  200: '#f0e9e7',
  300: '#e2d6cf',
  400: '#333',
  500: '#333',
  600: '#333',
  800: '#333',
}
