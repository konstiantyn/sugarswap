//export const sgr = '0xdAE59408fC12c439D6F7607af4261D6756d9E7CF'
export const sgrv2 = '0xdAE59408fC12c439D6F7607af4261D6756d9E7CF'
export const sgrAddress = '0x7d98cd88574968495BBA8eBB5bFFDE456ff2E35a'
export const masterChefAddress = '0x4871A9C53f6C86E98C1703B26cB111ba347d6f5e'
