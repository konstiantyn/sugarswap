export { default } from './Dial'
