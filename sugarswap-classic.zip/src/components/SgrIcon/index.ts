export { default } from './SgrIcon'
